// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/AnimInstance_Interface.h"

// Add default functionality here for any IAnimInstance_Interface functions that are not pure virtual.
